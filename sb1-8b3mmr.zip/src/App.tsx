import React, { useState, useEffect } from 'react';
import { PlusCircle, Clock, Trash2, Heart } from 'lucide-react';
import { TrackerForm } from './components/TrackerForm';
import { TrackerCard } from './components/TrackerCard';
import type { TimeTracker, ElapsedTime } from './types';

function HeartBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {[...Array(20)].map((_, i) => {
        const size = Math.random() * 24 + 12;
        const left = Math.random() * 100;
        const top = Math.random() * 100;
        const rotation = Math.random() * 360;
        const opacity = Math.random() * 0.15 + 0.05;

        return (
          <Heart
            key={i}
            className="absolute text-purple-300"
            style={{
              width: `${size}px`,
              height: `${size}px`,
              left: `${left}%`,
              top: `${top}%`,
              transform: `rotate(${rotation}deg)`,
              opacity,
            }}
            fill="currentColor"
          />
        );
      })}
    </div>
  );
}

function App() {
  const [trackers, setTrackers] = useState<TimeTracker[]>(() => {
    const saved = localStorage.getItem('timeTrackers');
    return saved ? JSON.parse(saved) : [];
  });
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    localStorage.setItem('timeTrackers', JSON.stringify(trackers));
  }, [trackers]);

  const addTracker = (data: Omit<TimeTracker, 'id'>) => {
    setTrackers([
      ...trackers,
      {
        id: crypto.randomUUID(),
        ...data,
      },
    ]);
  };

  const deleteTracker = (id: string) => {
    setTrackers(trackers.filter(tracker => tracker.id !== id));
  };

  const calculateElapsed = (startDate: string): ElapsedTime => {
    const start = new Date(startDate);
    const elapsed = currentTime.getTime() - start.getTime();

    const days = Math.floor(elapsed / (1000 * 60 * 60 * 24));
    const hours = Math.floor((elapsed % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((elapsed % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((elapsed % (1000 * 60)) / 1000);

    return { days, hours, minutes, seconds };
  };

  return (
    <div className="min-h-screen bg-gray-900 p-6 relative">
      <HeartBackground />
      <div className="max-w-4xl mx-auto relative">
        <div className="flex items-center gap-3 mb-8">
          <Clock className="w-8 h-8 text-purple-400" />
          <h1 className="text-3xl font-bold text-white">Time Tracker</h1>
        </div>

        <TrackerForm onSubmit={addTracker} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {trackers.map((tracker) => (
            <TrackerCard
              key={tracker.id}
              tracker={tracker}
              elapsed={calculateElapsed(tracker.startDate)}
              onDelete={deleteTracker}
            />
          ))}
        </div>

        {trackers.length === 0 && (
          <div className="text-center text-gray-400 mt-8">
            No trackers yet. Add one to get started!
          </div>
        )}
      </div>
    </div>
  );
}

export default App;