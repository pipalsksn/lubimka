export interface TimeTracker {
  id: string;
  label: string;
  startDate: string;
  color: string;
  icon: string;
}

export interface ElapsedTime {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export interface TrackerFormData {
  label: string;
  startDate: string;
  color: string;
  icon: string;
}