import React, { useState } from 'react';
import { PlusCircle } from 'lucide-react';
import { IconPicker } from './IconPicker';
import { ColorPicker } from './ColorPicker';
import type { TrackerFormData } from '../types';

interface TrackerFormProps {
  onSubmit: (data: TrackerFormData) => void;
}

export function TrackerForm({ onSubmit }: TrackerFormProps) {
  const [label, setLabel] = useState('');
  const [startDate, setStartDate] = useState('');
  const [color, setColor] = useState('#6366F1');
  const [icon, setIcon] = useState('Clock');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!label || !startDate) return;

    onSubmit({ label, startDate, color, icon });
    setLabel('');
    setStartDate('');
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-800 rounded-lg shadow-lg p-6 mb-8 border border-gray-700">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Label</label>
          <input
            type="text"
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 text-white placeholder-gray-400"
            placeholder="Enter tracker label"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Start Date</label>
          <input
            type="datetime-local"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 text-white"
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Icon</label>
          <IconPicker value={icon} onChange={setIcon} />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-300 mb-1">Color</label>
          <ColorPicker value={color} onChange={setColor} />
        </div>
        <div className="md:col-span-2 lg:col-span-4">
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-md hover:bg-purple-700 transition-colors"
          >
            <PlusCircle className="w-5 h-5" />
            Add Tracker
          </button>
        </div>
      </div>
    </form>
  );
}