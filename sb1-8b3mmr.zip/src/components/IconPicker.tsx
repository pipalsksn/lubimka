import React from 'react';
import * as Icons from 'lucide-react';

const iconList = [
  'Clock',
  'Timer',
  'Calendar',
  'Heart',
  'Star',
  'Sun',
  'Moon',
  'Coffee',
  'Music',
  'Book',
  'Rocket',
  'Target',
];

interface IconPickerProps {
  value: string;
  onChange: (icon: string) => void;
}

export function IconPicker({ value, onChange }: IconPickerProps) {
  return (
    <div className="relative">
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500 appearance-none text-white"
      >
        {iconList.map((iconName) => {
          const IconComponent = Icons[iconName as keyof typeof Icons];
          return (
            <option key={iconName} value={iconName}>
              {iconName}
            </option>
          );
        })}
      </select>
      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-white">
        {React.createElement(Icons[value as keyof typeof Icons], { size: 20 })}
      </div>
    </div>
  );
}