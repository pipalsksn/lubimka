import React from 'react';
import { Trash2 } from 'lucide-react';
import * as Icons from 'lucide-react';
import type { TimeTracker, ElapsedTime } from '../types';

interface TrackerCardProps {
  tracker: TimeTracker;
  elapsed: ElapsedTime;
  onDelete: (id: string) => void;
}

export function TrackerCard({ tracker, elapsed, onDelete }: TrackerCardProps) {
  const IconComponent = Icons[tracker.icon as keyof typeof Icons];

  return (
    <div className="bg-gray-800 rounded-lg shadow-lg p-6 relative group border border-gray-700">
      <button
        onClick={() => onDelete(tracker.id)}
        className="absolute top-4 right-4 text-gray-500 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
      >
        <Trash2 className="w-5 h-5" />
      </button>
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 rounded-lg" style={{ backgroundColor: `${tracker.color}20` }}>
          <IconComponent className="w-6 h-6" style={{ color: tracker.color }} />
        </div>
        <h3 className="text-xl font-semibold text-white">{tracker.label}</h3>
      </div>
      <div className="grid grid-cols-4 gap-4">
        <TimeUnit value={elapsed.days} label="Days" color={tracker.color} />
        <TimeUnit value={elapsed.hours} label="Hours" color={tracker.color} />
        <TimeUnit value={elapsed.minutes} label="Minutes" color={tracker.color} />
        <TimeUnit value={elapsed.seconds} label="Seconds" color={tracker.color} />
      </div>
      <div className="mt-4 text-sm text-gray-400">
        Started: {new Date(tracker.startDate).toLocaleString()}
      </div>
    </div>
  );
}

function TimeUnit({ value, label, color }: { value: number; label: string; color: string }) {
  return (
    <div className="text-center">
      <div className="text-2xl font-bold" style={{ color }}>{value}</div>
      <div className="text-sm text-gray-400">{label}</div>
    </div>
  );
}